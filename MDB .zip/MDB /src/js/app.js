
let bars = document.querySelector(".fa-bars-sort")
bars.addEventListener('click',function(){
document.body.classList.toggle("active")
})
let bars2 = document.querySelector(".fa-bars")
bars2.addEventListener('click',function(){
document.body.classList.toggle("active")
})
let cross = document.querySelector(".fa-square-xmark")
cross.addEventListener('click',function(){
document.body.classList.remove("active")
})
window.addEventListener("load",function(){
  document.body.classList.add("rent-tracker-active-1")

})
let rent_1 = document.querySelector('.rent-tracker-active-1')
rent_1.addEventListener('click',function(){
  document.body.classList.add("rent-tracker-active-1")
  document.body.classList.remove("rent-tracker-active-2","rent-tracker-active-3","rent-tracker-active-4")
})
let rent_2 = document.querySelector('.rent-tracker-active-2')
rent_2.addEventListener('click',function(){
  document.body.classList.add("rent-tracker-active-2")
  document.body.classList.remove("rent-tracker-active-1","rent-tracker-active-3","rent-tracker-active-4")

})
let rent_3 = document.querySelector('.rent-tracker-active-3')
rent_3.addEventListener('click',function(){
  document.body.classList.add("rent-tracker-active-3")
  document.body.classList.remove("rent-tracker-active-1","rent-tracker-active-2","rent-tracker-active-4")

})
let rent_4 = document.querySelector('.rent-tracker-active-4')
rent_4.addEventListener('click',function(){
  document.body.classList.add("rent-tracker-active-4")
  document.body.classList.remove("rent-tracker-active-1","rent-tracker-active-2","rent-tracker-active-3")

})
