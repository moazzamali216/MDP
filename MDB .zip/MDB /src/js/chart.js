if(document.querySelector("#chart-line")){
  console.log('working')
  var ctx1 = document.getElementById("chart-line").getContext("2d");

  var gradientStroke1 = ctx1.createLinearGradient(0, 230, 0, 50);

  gradientStroke1.addColorStop(1,  'rgba(55, 201, 157, 0.11)');
  gradientStroke1.addColorStop(0.2, 'rgba(55, 201, 157, 0.11) ');
  gradientStroke1.addColorStop(0, 'rgba(55, 201, 157, 0.11) ');
  new Chart(ctx1, {
      type: "line",
      data: {
      labels: ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      datasets: [{
          label: "Mobile apps",
          tension: 0.4,
          borderWidth: 0,
          pointRadius: 0,
          borderColor: "#37C99D",
          backgroundColor: gradientStroke1,
          borderWidth: 5,
          fill: true,
          data: [50, 40, 300, 220, 500, 250, 400, 230, 500],
          maxBarThickness: 6

      }],
      },
      options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
          legend: {
          display: false,
          }
      },
      interaction: {
          intersect: false,
          mode: 'index',
      },
      scales: {
          y: {
          grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5]
          },
          ticks: {
              display: true,
              padding: 10,
              color: '#37C99D',
              font: {
              size: 14,
              family: "Open Sans",
              style: 'normal',
              lineHeight: 2
              },
          }
          },
          x: {
          grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
              borderDash: [5, 5]
          },
          ticks: {
              display: true,
              color: '#37C99D',
              padding: 20,
              font: {
              size: 14,
              family: "Open Sans",
              style: 'normal',
              lineHeight: 2
              },
          }
          },
      },
      },
  });
}

if(document.querySelector("#chart-line-2")){
  var ctx = document.getElementById("chart-line-2").getContext('2d');
  var myChart = new Chart(ctx, {
      
      type: 'doughnut',
      data: {
          labels: ["Vacant",	"Occupied"],
          datasets: [{    
              data: [400,	600], // Specify the data values array
          
              borderColor: ['transparent'], // Add custom color border 
              backgroundColor: ['#374C98', '#468A1C'], // Add custom color background (Points and Fill)
              borderWidth: 0.3 // Specify bar border width
              
          }]},  
                 
      options: {
      responsive: true, // Instruct chart js to respond nicely.
      maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height 
      cutout: 70,
      plugins: {
          legend: {
              display: true,
              labels: {
                  color: '#3F4254',
              }
          }
      }
      },
  });
}
if(document.querySelector("#chart-line-3")){
    var ctx = document.getElementById("chart-line-3").getContext('2d');
    var myChart = new Chart(ctx, {
        
        type: 'doughnut',
        data: {
            labels: ["Vacant",	"Occupied"],
            datasets: [{    
                data: [400,	600], // Specify the data values array
            
                borderColor: ['transparent'], // Add custom color border 
                backgroundColor: ['#374C98', '#468A1C'], // Add custom color background (Points and Fill)
                borderWidth: 0.3 // Specify bar border width
                
            }]},  
                   
        options: {
        responsive: true, // Instruct chart js to respond nicely.
        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height 
        cutout: 70,
        plugins: {
            legend: {
                display: true,
                labels: {
                    color: '#3F4254',
                }
            }
        }
        },
    });
  }
  
