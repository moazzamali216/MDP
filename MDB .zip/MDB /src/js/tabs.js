if(document.querySelector("#profile-tab-example")){
  // create an array of objects with the id, trigger element (eg. button), and the content element
  const tabElements = [
      {
          id: 'profile',
          triggerEl: document.querySelector('#profile-tab-example'),
          targetEl: document.querySelector('#profile-example')
      },
      {
          id: 'dashboard',
          triggerEl: document.querySelector('#dashboard-tab-example'),
          targetEl: document.querySelector('#dashboard-example')
      },
      {
          id: 'settings',
          triggerEl: document.querySelector('#settings-tab-example'),
          targetEl: document.querySelector('#settings-example')
      },
      {
          id: 'contacts',
          triggerEl: document.querySelector('#contacts-tab-example'),
          targetEl: document.querySelector('#contacts-example')
      },
      {
        id: 'lease',
        triggerEl: document.querySelector('#lease-tab-example'),
        targetEl: document.querySelector('#lease-example')
    },
    {
      id: 'inventory',
      triggerEl: document.querySelector('#inventory-tab-example'),
      targetEl: document.querySelector('#inventory-example')
  },
  {
    id: 'action',
    triggerEl: document.querySelector('#action-tab-example'),
    targetEl: document.querySelector('#action-example')
},
{
  id: 'rooms',
  triggerEl: document.querySelector('#room-tab-example'),
  targetEl: document.querySelector('#room-example')
}
      ];

      // options with default values
      const options = {
          defaultTabId: 'profile',
          activeClasses:'text-green-400 hover:text-green-500 dark:text-blue-500 dark:hover:text-blue-400 border-green-400 dark:border-blue-500',
          inactiveClasses:'text-gray-500 hover:text-gray-600 dark:text-gray-400 border-gray-100 hover:border-gray-300 dark:border-gray-700 dark:hover:text-gray-300',
          onShow: () => {
              console.log('tab is shown');
          }
      };
  const tabs = new Tabs(tabElements, options);
}
window.addEventListener("load",function(){
    document.body.classList.add("tab1-tracker-active-1")
  
  })
  let tab1_1 = document.querySelector('.tab1-tracker-active-1')
  tab1_1.addEventListener('click',function(){
    document.body.classList.add("tab1-tracker-active-1")
    document.body.classList.remove("tab1-tracker-active-2","tab1-tracker-active-3","tab1-tracker-active-4")
  })
  let tab1_2 = document.querySelector('.tab1-tracker-active-2')
  tab1_2.addEventListener('click',function(){
    document.body.classList.add("tab1-tracker-active-2")
    document.body.classList.remove("tab1-tracker-active-1","tab1-tracker-active-3","tab1-tracker-activee-4")
  
  })
  let tab1_3 = document.querySelector('.tab1-tracker-active-3')
  tab1_3.addEventListener('click',function(){
    document.body.classList.add("tab1-tracker-active-3")
    document.body.classList.remove("tab1-tracker-active-1","tab1-tracker-active-2","tab1-tracker-active-4")
  
  })
  window.addEventListener("load",function(){
    document.body.classList.add("tab2-tracker-active-1")
  
  })
  let tab2_1 = document.querySelector('.tab2-tracker-active-1')
  tab2_1.addEventListener('click',function(){
    document.body.classList.add("tab2-tracker-active-1")
    document.body.classList.remove("tab2-tracker-active-2","tab2-tracker-active-3","tab2-tracker-active-4")
  })
  let tab2_2 = document.querySelector('.tab2-tracker-active-2')
  tab2_2.addEventListener('click',function(){
    document.body.classList.add("tab2-tracker-active-2")
    document.body.classList.remove("tab2-tracker-active-1","tab2-tracker-active-3","tab2-tracker-activee-4")
  
  })
  let tab2_3 = document.querySelector('.tab2-tracker-active-3')
  tab2_3.addEventListener('click',function(){
    document.body.classList.add("tab2-tracker-active-3")
    document.body.classList.remove("tab2-tracker-active-1","tab2-tracker-active-2","tab2-tracker-active-4")
  
  })


